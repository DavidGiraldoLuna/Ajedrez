package view;

import controller.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import model.*;

// Clase principal que extiende JFrame e implementa ActionListener
public class Main extends JFrame implements ActionListener {
    // Layout y constraints para el diseño de la interfaz
    private final GridBagLayout layout;
    private final GridBagConstraints constraints;

    // Panel de información
    JPanel infoPanel;

    // Botones de la interfaz
    JButton btnPgn, btnFirstGame, btnLastGame, btnPreGame, btnNxtGame,
            btnReset, btnEnd, btnPreMove, btnNxtMove,
            btnSearchGame, btnSearchMove, btnSave, btnPlay;

    // Áreas de texto para etiquetas y movimientos
    JTextArea tagsArea, movesArea;

    // Scroll panes para las áreas de texto
    JScrollPane scrollTags, scrollMoves;

    // Campos de texto para búsqueda de juegos y movimientos
    JTextField searchGame, searchMove;

    // Etiquetas para los campos de búsqueda
    JLabel searchGameLabel, searchMoveLabel, pgnLabel, gameLabel, moveLabel, colorLabel;

    // Botones de radio para seleccionar el color de las piezas
    JRadioButton whiteRadio, blackRadio;

    // Checkbox para usar figuras en lugar de letras
    JCheckBox figurineBox;

    // Grupo de botones para los botones de radio
    ButtonGroup bg;

    // Temporizador para la reproducción automática de movimientos
    Timer timer;

    // Objetos PGN y Game para manejar los datos del juego
    private PGN pgn;
    private Game game;

    // Variables de estado
    private boolean isSelected, isMove, notFlip, isPlay, isFigurine, isTop5;
    private int indexOfGame, indexOfMove;


    public Main(){
        super("Ajedrez PGN");

        layout = new GridBagLayout();

        setLayout(layout);
        constraints = new GridBagConstraints();

        notFlip = true;
        indexOfMove = -1;
        timer = new Timer(750, this);
        timer.start();
        setResizable(false);


        tagsArea = new JTextArea(8, 15);
        scrollTags = setTextArea(tagsArea);


        movesArea = new JTextArea (8 , 10);
        scrollMoves = setTextArea(movesArea);

        infoPanel = new JPanel();
        infoPanel.setPreferredSize(new Dimension(80, 250));
        infoPanel.setLayout(layout);
        pgnLabel = new JLabel("");
        moveLabel = new JLabel("");
        colorLabel = new JLabel("");
        gameLabel = new JLabel("");

        figurineBox = new JCheckBox("Ficha");
        figurineBox.addItemListener(e -> {
            isFigurine = figurineBox.isSelected();
            if(figurineBox.isSelected())
                movesArea.setText(figurineText(game.getStrMovesText()));
            else
                movesArea.setText(game.getStrMovesText());
            highlightMove();
        });

        constraints.insets = new Insets(0, 0, 10, 0);

        constraints.insets = new Insets(0, 0, 9, 0);

        constraints.insets = new Insets(0, 0, 6, 0);



        btnPgn = new JButton ("Abrir archivo PGN");
        btnPgn.addActionListener(e -> {
            JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
            j.setAcceptAllFileFilterUsed(false);
            j.setDialogTitle("Selecciona un archivo");
            FileNameExtensionFilter restrict = new FileNameExtensionFilter("Archivos de notacion portatil (.pgn)", "pgn");
            j.addChoosableFileFilter(restrict);
            int r = j.showOpenDialog(null);
            if (r == JFileChooser.APPROVE_OPTION) {
                pgn = new PGN(j.getSelectedFile().getAbsolutePath());




                isSelected = true;
                indexOfGame = 0;

                String nameOfFile = j.getSelectedFile().getName();
                pgnLabel.setText(nameOfFile.substring(0, nameOfFile.length()-4));

                setGameButton();
            }
        });



        btnReset = new JButton ("Resetear");
        btnReset.addActionListener(e -> {
            if(isSelected){

                isMove = false;
                isPlay = false;
                indexOfMove = -1;


                game.board.resetBoard();


                int size = game.board.getMoves().size();
                size = (size/2)+(size%2);
                moveLabel.setText("Movimiento "+(indexOfMove + 1)+" de "+size);
                colorLabel.setText("");

                btnPlay.setText("Reproducir");

                highlightMove();
                repaint();
            }
        });

        btnEnd = new JButton ("Final");
        btnEnd.addActionListener(e -> {
            if(isSelected && indexOfMove < game.board.getMoves().size()-1){

                isMove = true;
                isPlay = false;
                indexOfMove = game.board.getMoves().size()-1;


                for(int i = 0; i <= indexOfMove; i++)
                    game.board.doMove(game.board.getMoves().get(i));


                int size = game.board.getMoves().size();
                size = (size/2)+(size%2);
                if(indexOfMove+1 != 0 && (indexOfMove+1) % 2 == 1) {
                    moveLabel.setText("Movimiento " + ((indexOfMove + 2) / 2) + " de " + size);
                    colorLabel.setText("Piezas blancas");
                }
                else if(indexOfMove+1 != 0) {
                    moveLabel.setText("Movimiento " + ((indexOfMove + 1) / 2) + " de " + size);
                    colorLabel.setText("Piezas negras");
                }

                btnPlay.setText("Reproducir");

                highlightMove();
                repaint();
            }
        });


        btnPreMove = new JButton ("Movimiento anterior");
        btnPreMove.addActionListener(e -> {
            if(isSelected && indexOfMove >= 0){

                isMove = true;
                isPlay = false;
                indexOfMove--;


                game.board.undoMove();


                int size = game.board.getMoves().size();
                size = (size/2)+(size%2);
                if(indexOfMove+1 != 0 && (indexOfMove+1) % 2 == 1) {
                    moveLabel.setText("Movimiento " + ((indexOfMove + 2) / 2) + " de " + size);
                    colorLabel.setText("Piezas blancas");
                }
                else if(indexOfMove+1 != 0) {
                    moveLabel.setText("Movimiento " + ((indexOfMove + 1) / 2) + " de " + size);
                    colorLabel.setText("Piezas negras");
                }
                else {
                    moveLabel.setText("Primer movimiento de " + size);
                    colorLabel.setText("");
                }

                btnPlay.setText("Reproducir");

                highlightMove();
                repaint();
            }
        });

        btnNxtMove = new JButton ("Siguiente movimiento");
        btnNxtMove.addActionListener(e -> {
            if(isSelected && indexOfMove < game.board.getMoves().size()-1){

                isMove = true;
                isPlay = false;
                indexOfMove++;


                game.board.doMove(game.board.getMoves().get(indexOfMove));


                int size = game.board.getMoves().size();
                size = (size/2)+(size%2);
                if(indexOfMove+1 != 0 && (indexOfMove+1) % 2 == 1) {
                    moveLabel.setText("Movimiento " + ((indexOfMove + 2) / 2) + " de " + size);
                    colorLabel.setText("Piezas blancas");
                }
                else if(indexOfMove+1 != 0) {
                    moveLabel.setText("Movimiento " + ((indexOfMove + 1) / 2) + " de " + size);
                    colorLabel.setText("Piezas negras");
                }

                btnPlay.setText("Reproducir");

                highlightMove();
                repaint();
            }
        });

        searchMove = new JTextField(5);
        searchMoveLabel = new JLabel("Movimiento No.:");
        whiteRadio = new JRadioButton("Piezas blancas");
        blackRadio = new JRadioButton("Piezas negras");
        bg = new ButtonGroup();
        bg.add(whiteRadio); bg.add(blackRadio);
        btnSearchMove = new JButton("Buscar");
        btnSearchMove.addActionListener(e -> {
            if(isSelected && searchMove.getText() != null){
                int index = (Integer.parseInt(searchMove.getText())-1)*2;
                if(index >= 0 && index < game.board.getMoves().size()) {
                    if(blackRadio.isSelected())
                        index++;
                    if(index > indexOfMove) {
                        for (int i = indexOfMove + 1; i <= index; i++)
                            game.board.doMove(game.board.getMoves().get(i));
                        indexOfMove = index;
                    }
                    else if(index < indexOfMove){
                        while (index != indexOfMove){
                            indexOfMove--;
                            game.board.undoMove();
                        }
                    }
                    isMove = true;
                    int size = game.board.getMoves().size();
                    size = (size/2)+(size%2);
                    if(indexOfMove+1 != 0 && (indexOfMove+1) % 2 == 1) {
                        moveLabel.setText("Movimiento " + ((indexOfMove + 2) / 2) + " de " + size);
                        colorLabel.setText("White");
                    }
                    else if(indexOfMove+1 != 0) {
                        moveLabel.setText("Movimiento " + ((indexOfMove + 1) / 2) + " de " + size);
                        colorLabel.setText("Piezas negras");
                    }
                }
                else if(index == -2){
                    indexOfMove = -1;
                    isMove = false;
                    game.board.resetBoard();
                    int size = game.board.getMoves().size();
                    size = (size/2)+(size%2);
                    moveLabel.setText("Movimiento "+(indexOfMove + 1)+" de "+size);
                    colorLabel.setText("");
                }
                isPlay = false;
                btnPlay.setText("Reproducir");
                highlightMove();
                repaint();
            }
        });



        btnPlay = new JButton ("Reproducir");
        btnPlay.addActionListener(e -> {
            if(isSelected && indexOfMove < game.board.getMoves().size()-1) {
                isPlay = !isPlay;
                if (isPlay)
                    btnPlay.setText("Pausa");
                else
                    btnPlay.setText("Reanudar");
            }
        });


        constraints.insets = new Insets(0, 0, 0, 0);
        addComponent(new ChessBoard(), 0, 0, 8,8);

        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 1;


        constraints.insets = new Insets(10, 5, 0, 5);
        addComponent(btnPgn, 2 , 8 , 9 , 1);


        constraints.insets = new Insets(5, 5, 0, 2);
        addComponent(btnPreMove, 3 , 11 , 2 , 1);

        constraints.insets = new Insets(5, 3, 0, 5);
        addComponent(btnNxtMove, 3 , 13 , 2 , 1);

        constraints.insets = new Insets(5, 5, 0, 2);
        addComponent(btnReset, 4 , 13 , 2 , 1);

        constraints.insets = new Insets(5, 3, 0, 5);
        addComponent(btnEnd, 3 , 15 , 2 , 1);

        constraints.insets = new Insets(5, 5, 0, 2);
        addComponent(searchMoveLabel, 5 , 13 , 1 , 1);

        constraints.insets = new Insets(5, 3, 0, 5);
        addComponent(searchMove, 5 , 14 , 1 , 1);

        constraints.insets = new Insets(5, 5, 0, 2);
        addComponent(whiteRadio, 5 , 15 , 1 , 1);

        constraints.insets = new Insets(5, 3, 0, 5);
        addComponent(blackRadio, 5 , 16, 1 , 1);

        constraints.insets = new Insets(5, 3, 0, 5);
        addComponent(btnSearchMove, 4 , 15 , 2 , 1);

        constraints.insets = new Insets(5, 5, 0, 2);
        addComponent(btnPlay, 4 , 10 ,3, 1);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setVisible(true);
        setLocationRelativeTo(null);
    }


    private class ChessBoard extends JPanel{
        final int UNIT_SIZE = 60;
        final int SCREEN_SIZE = 8*UNIT_SIZE;

        ChessBoard() {
            setPreferredSize(new Dimension(SCREEN_SIZE, SCREEN_SIZE));
            setBackground(new Color(255, 241, 200));
            setFocusable(true);
        }

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            draw(g);
        }

        public void draw(Graphics g) {

            g.setColor(new Color(175, 115, 70));
            for(int i = 0; i <= SCREEN_SIZE; i += UNIT_SIZE) {
                for(int j = 0; j <= SCREEN_SIZE; j += UNIT_SIZE) {
                    if (((i / UNIT_SIZE) % 2 == 0 && (j / UNIT_SIZE) % 2 != 0)
                            || ((i / UNIT_SIZE) % 2 != 0 && (j / UNIT_SIZE) % 2 == 0))
                        g.fillRect(i, j, UNIT_SIZE, UNIT_SIZE);
                }
            }


            if(isMove){
                Move move;
                if(indexOfMove >= 0)
                    move = game.board.getMoves().get(indexOfMove);
                else
                    move = game.board.getMoves().get(0);
                g.setColor(new Color(231, 231, 0));
                if(move.getTypeOfConstructor() != 3) {
                    int[] s1 = Method.getPosition(move.getFrom());
                    int[] s2 = Method.getPosition(move.getTo());
                    if(notFlip) {
                        g.fillRect(s1[1] * UNIT_SIZE, (7 - s1[0]) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                        g.fillRect(s2[1] * UNIT_SIZE, (7 - s2[0]) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                    } else {
                        g.fillRect((7-s1[1]) * UNIT_SIZE, (s1[0]) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                        g.fillRect((7-s2[1]) * UNIT_SIZE, (s2[0]) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                    }
                } else {
                    if(move.isWhite()){
                        if(move.isKingSideCastle()){
                            if(notFlip) {
                                g.fillRect((6) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((4) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                            } else {
                                g.fillRect( UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((3) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                            }
                        }
                        else if(move.isQueenSideCastle()){
                            if(notFlip) {
                                g.fillRect((4) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((2) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                            } else {
                                g.fillRect((3) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((5) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                            }
                        }
                    } else{
                        if(move.isKingSideCastle()){
                            if(notFlip) {
                                g.fillRect((6) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((4) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                            } else {
                                g.fillRect( UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((3) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                            }
                        }
                        else if(move.isQueenSideCastle()){
                            if(notFlip) {
                                g.fillRect((4) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((2) * UNIT_SIZE, 0, UNIT_SIZE, UNIT_SIZE);
                            } else {
                                g.fillRect((3) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                                g.fillRect((5) * UNIT_SIZE, (7) * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
                            }
                        }
                    }
                }
            }


            g.setFont(new Font("Arial", Font.BOLD, 15));
            for(int i = 8; i > 0; i--){
                if(i % 2 == 1)
                    g.setColor(new Color(210, 165, 125));
                else
                    g.setColor(new Color(175, 114, 70));
                g.drawString(String.valueOf(i),2,13+UNIT_SIZE*(8-i));
                g.drawString(String.valueOf((char)(i+96)),(i)*UNIT_SIZE-10,8*UNIT_SIZE-5);
            }


            BufferedImage image = null;
            try {
                for(int i = 0; i < 8; i++) {
                    for (int j = 0; j < 8; j++) {
                        Piece piece = Method.getPiece(new int[]{i, j});
                        if(piece != Piece.NONE) {
                            switch (piece) {
                                case WHITE_PAWN -> image = ImageIO.read(new File("src/resources/wp.png"));
                                case BLACK_PAWN -> image = ImageIO.read(new File("src/resources/bp.png"));
                                case WHITE_ROOK -> image = ImageIO.read(new File("src/resources/wr.png"));
                                case BLACK_ROOK -> image = ImageIO.read(new File("src/resources/br.png"));
                                case WHITE_KNIGHT -> image = ImageIO.read(new File("src/resources/wn.png"));
                                case BLACK_KNIGHT -> image = ImageIO.read(new File("src/resources/bn.png"));
                                case WHITE_BISHOP -> image = ImageIO.read(new File("src/resources/wb.png"));
                                case BLACK_BISHOP -> image = ImageIO.read(new File("src/resources/bb.png"));
                                case WHITE_QUEEN -> image = ImageIO.read(new File("src/resources/wq.png"));
                                case BLACK_QUEEN -> image = ImageIO.read(new File("src/resources/bq.png"));
                                case WHITE_KING -> image = ImageIO.read(new File("src/resources/wk.png"));
                                case BLACK_KING -> image = ImageIO.read(new File("src/resources/bk.png"));
                            }
                            if(notFlip)
                                g.drawImage(image, j * UNIT_SIZE, (7-i) * UNIT_SIZE, null);
                            else
                                g.drawImage(image, (7-j) * UNIT_SIZE, i * UNIT_SIZE, null);
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    private void addComponent(Component component, int row, int column, int width, int height) {
        constraints.gridx = column;
        constraints.gridy = row;
        constraints.gridwidth = width;
        constraints.gridheight = height;
        layout.setConstraints(component, constraints);
        add(component);
    }


    private JScrollPane setTextArea(JTextArea textArea){
        textArea.setFont(new Font("Sans-Serif", Font.BOLD, 15));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setEditable(false);
        return new JScrollPane(textArea, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
    }


    private void setGameButton(){

        isMove = false;
        isPlay = false;
        indexOfMove = -1;

        game = pgn.getGames().get(indexOfGame);
        game.board = new Board(Converter.convertMoves(game.getStringMovesArray()));
        game.board.resetBoard();


        tagsArea.setText(game.toString());
        if(isFigurine)
            movesArea.setText(figurineText(game.getStrMovesText()));
        else
            movesArea.setText(game.getStrMovesText());

        int size = game.board.getMoves().size();
        size = (size/2)+(size%2);
        moveLabel.setText("Movimiento "+(indexOfMove + 1)+" de "+size);
        colorLabel.setText("");


        btnPlay.setText("Reproducir");

        repaint();
    }


    private void play(){
        if(isSelected && indexOfMove < game.board.getMoves().size()-1){
            indexOfMove++;
            isMove = true;
            game.board.doMove(game.board.getMoves().get(indexOfMove));
            int size = game.board.getMoves().size();
            size = (size/2)+(size%2);
            if(indexOfMove+1 != 0 && (indexOfMove+1) % 2 == 1) {
                moveLabel.setText("Movimiento " + ((indexOfMove + 2) / 2) + " de " + size);
                colorLabel.setText("Piezas blancas");
            }
            else if(indexOfMove+1 != 0) {
                moveLabel.setText("Movimiento " + ((indexOfMove + 1) / 2) + " de " + size);
                colorLabel.setText("Piezas negras");
            }
            highlightMove();
        }
    }


    private void highlightMove(){
        Highlighter highlighter = movesArea.getHighlighter();
        Highlighter.HighlightPainter painter = new DefaultHighlighter.DefaultHighlightPainter(new Color(0, 231, 204));
        highlighter.removeAllHighlights();
        if(indexOfMove >= 0) {
            int indexOfMoveText;
            if((indexOfMove+1) % 2 == 1) {
                indexOfMoveText = movesArea.getText().indexOf(String.valueOf((indexOfMove + 2) / 2));
            }
            else {
                indexOfMoveText = movesArea.getText().indexOf(String.valueOf((indexOfMove + 1) / 2));
            }
            if(colorLabel.getText().equals("Piezas negras"))
                indexOfMoveText += game.board.getMoves().get(indexOfMove-1).getStringMove().length();
            String strMove;
            if(isFigurine)
                strMove = toFigurine(game.board.getMoves().get(indexOfMove).getStringMove());
            else
                strMove = game.board.getMoves().get(indexOfMove).getStringMove();
            int p0 = movesArea.getText().indexOf(strMove, indexOfMoveText);
            int p1 = p0 + strMove.length();
            try {
                highlighter.addHighlight(p0, p1, painter);
            } catch (BadLocationException e) {
                e.printStackTrace();
            }
        }
    }


    private String toFigurine(String s){
        if(indexOfMove % 2 == 0){
            for(int i = 0; i < s.length(); i++) {
                switch (s.charAt(i)) {
                    case 'R' -> s = s.replaceFirst("R", "♖");
                    case 'N' -> s = s.replaceFirst("N", "♘");
                    case 'B' -> s = s.replaceFirst("B", "♗");
                    case 'Q' -> s = s.replaceFirst("Q", "♕");
                    case 'K' -> s = s.replaceFirst("K", "♔");
                }
            }
        } else {
            for(int i = 0; i < s.length(); i++) {
                switch (s.charAt(i)) {
                    case 'R' -> s = s.replaceFirst("R", "♜");
                    case 'N' -> s = s.replaceFirst("N", "♞");
                    case 'B' -> s = s.replaceFirst("B", "♝");
                    case 'Q' -> s = s.replaceFirst("Q", "♛");
                    case 'K' -> s = s.replaceFirst("K", "♚");
                }
            }
        }
        return s;
    }


    private String figurineText(String s){
        for(int i = 0; i < s.length(); i++) {
            if(i > 1)
                i--;
            if (s.charAt(i) == '.') {
                i++;
                while(s.charAt(i) != '.') {
                    if(s.charAt(i) == ' ')
                        i++;
                    while(s.charAt(i) != ' ') {
                        switch (s.charAt(i)) {
                            case 'R' -> s = s.replaceFirst("R", "♖");
                            case 'N' -> s = s.replaceFirst("N", "♘");
                            case 'B' -> s = s.replaceFirst("B", "♗");
                            case 'Q' -> s = s.replaceFirst("Q", "♕");
                            case 'K' -> s = s.replaceFirst("K", "♔");
                        }
                        i++;
                    }
                    while(s.charAt(i) != '.') {
                        switch (s.charAt(i)) {
                            case 'R' -> s = s.replaceFirst("R", "♜");
                            case 'N' -> s = s.replaceFirst("N", "♞");
                            case 'B' -> s = s.replaceFirst("B", "♝");
                            case 'Q' -> s = s.replaceFirst("Q", "♛");
                            case 'K' -> s = s.replaceFirst("K", "♚");
                        }
                        i++;
                        if(i >= s.length())
                            break;
                    }
                    if(i >= s.length())
                        break;
                }
            }
        }
        return s;
    }

    // Método que se ejecuta cuando se realiza una acción
    @Override
    public void actionPerformed(ActionEvent e) {
        if(isPlay) {
            // Reproduce el siguiente movimiento
            play();
            // Si se ha llegado al último movimiento, se detiene la reproducción
            if(indexOfMove == game.board.getMoves().size()-1){
                isPlay = false;
                btnPlay.setText("Reproducir");
            }
            // Redibuja el componente
            repaint();
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::new);
    }
}